# Leak Scan Report Template

## Report Metadata
- report_file:
- timestamp:
- scan_version:

## Active Rules
- HOME_PATH
- USERNAME
- IPV4
- RUN_ID
- TOKENS_GENERIC
- URL_INTERNAL
- HOSTNAME

## Detections Summary
- total_detections:
- passed: true|false

## Per-Rule Detections
- HOME_PATH: <count>
- USERNAME: <count>
- IPV4: <count>
- RUN_ID: <count>
- TOKENS_GENERIC: <count>
- URL_INTERNAL: <count>
- HOSTNAME: <count>

## Known False Positives
- <rule>: <reason>

## Output Hash (clean)
- sha256:
