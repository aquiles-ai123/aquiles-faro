# Canary Public Report

API_KEY=<redacted>
TOKEN=<redacted>
AWS_SECRET=<redacted>
SECRET_KEY=<redacted>
PRIVATE_KEY=<redacted>
API_KEY=<redacted>
TOKEN=<redacted>
AWS_SECRET=<redacted>
SECRET_KEY=<redacted>
PRIVATE_KEY=<redacted>
{
  "run_id": "20260125_173159_f43ce7",
  "dir": "/tmp/aquiles_canary/20260125_173159_f43ce7",
  "canaries": [
    "API_KEY=<redacted>
    "TOKEN=<redacted>
    "AWS_SECRET=<redacted>
    "SECRET_KEY=<redacted>
    "PRIVATE_KEY=<redacted>
  ],
  "timestamp": "2026-01-25T17:31:59"
}
# Canary
API_KEY=<redacted>
TOKEN=<redacted>
AWS_SECRET=<redacted>
SECRET_KEY=<redacted>
PRIVATE_KEY=<redacted>
