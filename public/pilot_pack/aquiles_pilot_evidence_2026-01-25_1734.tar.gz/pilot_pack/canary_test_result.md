# Canary Test Result
- run_id: 20260125_173325_d4ad4f
- report: /home/cryptotrading74/AQUILES/aquiles_runtime/reports/pilot_pack/canary_public_report_20260125_173325_d4ad4f.md
- status: PASS
