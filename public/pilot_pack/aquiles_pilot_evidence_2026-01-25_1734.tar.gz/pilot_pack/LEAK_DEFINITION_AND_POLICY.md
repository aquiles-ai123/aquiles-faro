# Leak Definition and Policy

## Definición formal de “leak”
Se considera leak cualquier dato sensible expuesto en un artefacto público:

**PII**
- Nombres de usuario locales, emails, teléfonos, direcciones.

**Secretos/tokens**
- API keys, tokens, credenciales, claves privadas.

**URLs internas**
- URLs con localhost, 127.0.0.1 o IPs privadas.

**Hostnames**
- Nombres de host internos o dominios privados.

**Rutas locales**
- /home/usuario/... u otras rutas absolutas del sistema.

**IDs de ejecución**
- run_id, job_id o identificadores internos.

**IPs**
- Cualquier IPv4 (prioridad en privadas/loopback).

**Números sensibles**
- IDs de cuenta, keys, hashes que identifiquen a personas.

## Qué cubre hoy
- Sanitización en reportes públicos (paths, username, IPv4, run_id, tokens genéricos).
- Leak scan automático con reglas explícitas.

## Qué NO cubre hoy
- Contenido embebido en imágenes/PDFs/binaries.
- Base64 u otros formatos comprimidos sin decodificar.
- Información derivada de correlación (re-identificación estadística).

## Política ante leak
- **Block**: si el leak es crítico (tokens/PII).
- **Redact**: si es ruta/ID interno sin valor público.
- **Alert**: registrar incidente y re-ejecutar pipeline.

## Retención
- Logs JSONL: append-only (auditable).
- Reportes: se almacenan en runtime/reports.
- Public artifacts: Faro/public. Retención configurable.
