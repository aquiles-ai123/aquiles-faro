# Threat Model (2 pages)

## Threats & Mitigations

### 1) Prompt Injection (si aplica)
- Riesgo: inputs maliciosos alteran el output.
- Mitigación: sanitización previa, límites de contexto, no ejecutar acciones.

### 2) Exfiltración de secretos
- Riesgo: reportes públicos con datos sensibles.
- Mitigación: reglas explícitas de sanitización + leak scan automático.

### 3) Supply Chain
- Riesgo: dependencias vulnerables.
- Mitigación: SBOM + patching SLA + revisión periódica.

### 4) Logs con secretos
- Riesgo: secrets quedan en JSONL.
- Mitigación: minimizar logging, redactar antes de persistir, auditoría.

### 5) Redacción incompleta
- Riesgo: patrones no cubiertos.
- Mitigación: canary tests + ajustes incrementales de reglas.

### 6) Publicación accidental
- Riesgo: se publica sin revisión.
- Mitigación: block en leaks críticos, sólo publicar si scan = pass.

### 7) Dependencia vulnerable
- Riesgo: exposición vía librerías.
- Mitigación: SBOM + CVE scanning.

### 8) Insider
- Riesgo: acceso interno a outputs.
- Mitigación: logs auditables, principio de mínimo privilegio.

## Supuestos
- El cliente provee repos/ZIP sin malware ejecutable.
- El pipeline no ejecuta código.

## Out of Scope
- Análisis dinámico de malware.
- Forensics avanzada.
- Re-identificación estadística.

## Controles Clave
- Offline mode opcional.
- Allowlist de entradas.
- Sanitización pre-publicación.
- No‑exec policy (sin build, sin postinstall, sin notebooks).
