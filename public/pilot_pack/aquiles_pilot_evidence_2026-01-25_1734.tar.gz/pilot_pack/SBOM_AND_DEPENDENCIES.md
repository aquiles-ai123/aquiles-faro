# SBOM & Dependencies

## Objetivo
Mantener visibilidad de dependencias y respuesta rápida a CVEs.

## Generación SBOM
- pip freeze → pip_freeze.txt
- CycloneDX (si tool disponible) → bom.json

## Proceso
1) Generar SBOM con script.
2) Revisar CVEs (manual o tooling externo).
3) Parchar en SLA definido.

## Comando
```bash
bash /home/cryptotrading74/AQUILES/aquiles_pro_linux_mvp/scripts/sbom_generate.sh
```
