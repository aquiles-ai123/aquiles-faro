# Canary Test Plan

## Objetivo
Validar que los canary secrets NO aparecen en artefactos públicos y que el leak scan los detecta si estuvieran presentes.

## Canary patterns (ejemplos)
- API_KEY=CANARY_API_KEY_123456
- TOKEN=CANARY_TOKEN_ABCDEF
- AWS_SECRET=CANARY_AWS_SECRET_0001
- SECRET_KEY=CANARY_SECRET_9999
- PRIVATE_KEY=-----BEGIN PRIVATE KEY-----CANARY

## Criterios de aprobación
- Leak scan pasa (passed=true).
- Ningún canary aparece en output público.

## Cómo correr
```bash
python3 /home/cryptotrading74/AQUILES/aquiles_pro_linux_mvp/scripts/canary_generate_inputs.py
bash /home/cryptotrading74/AQUILES/aquiles_pro_linux_mvp/scripts/canary_run_test.sh
```

## Resultado esperado
- Archivo: runtime/reports/pilot_pack/canary_test_result.md
- Passed=true
