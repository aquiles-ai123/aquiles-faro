# Offline Mode

## Objetivo
Demostrar que el pipeline puede operar sin red (cuando no depende de LLM remoto).

## Qué funciona
- Leak scan
- Canary tests
- Repo Health mock (análisis estático local)

## Qué se pierde
- LLM remoto (si el modelo está fuera del dispositivo)
- Webhooks externos

## Checklist offline
```bash
# Desconectar red
# Ejecutar:
python3 /home/cryptotrading74/AQUILES/aquiles_pro_linux_mvp/scripts/leak_scan.py
bash /home/cryptotrading74/AQUILES/aquiles_pro_linux_mvp/scripts/canary_run_test.sh
```

## Indicadores
- Reportes generados en runtime/reports/pilot_pack
- Sin llamadas externas (revisar logs)
