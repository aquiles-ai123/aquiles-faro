# Pilot Install Guide

## Requisitos
- Linux
- Python 3.10+
- Espacio libre: 1–2 GB

## Instalación
```bash
cd /home/cryptotrading74/AQUILES/aquiles_pro_linux_mvp
python3 -m venv .venv_pilot
source .venv_pilot/bin/activate
pip install -r product_autopilot/requirements.txt
```

## Demo 5 min
```bash
uvicorn product_autopilot.app:app --port 8000
# abrir landing en browser
```

## Troubleshooting
- Verificar envs (MIN_PRICE_CLP, MP_MOCK)
- Verificar permisos de escritura en /tmp y runtime
