# Reproducibility & Audit

## Repro bundle por reporte
Incluye:
- manifest.json (hashes de inputs/outputs)
- config no sensible (version, flags)
- output publicado

## Logs
- JSONL append-only en runtime/hub/events.jsonl
- Evitar secretos: sanitización antes de persistir

## Cómo generar un repro bundle
```bash
bash /home/cryptotrading74/AQUILES/aquiles_pro_linux_mvp/scripts/repro_bundle.sh \
  /home/cryptotrading74/AQUILES/aquiles_runtime/reports/engine_health_public_2026-01-25.md
```
