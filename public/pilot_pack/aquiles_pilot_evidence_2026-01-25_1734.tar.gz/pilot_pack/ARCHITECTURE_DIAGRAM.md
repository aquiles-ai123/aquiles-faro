# Architecture Diagram

```mermaid
flowchart TD
  A[Inputs: repo_url or ZIP] --> B[Ingest]
  B --> C[Sanitize]
  C --> D[Generate Report]
  D --> E[Leak Scan]
  E -->|pass| F[Publish Faro]
  E -->|fail| G[Block + Alert]
  F --> H[Deliver]
```

## Inputs permitidos
- Repo URL público (git clone --depth 1)
- ZIP del repo (sin ejecución)

## Inputs NO permitidos
- Repos privados sin autorización
- Ejecutables/binaries como entrada principal
- Entregas con scripts ejecutables

## Política No‑Exec (precisa)
- No hooks
- No build
- No postinstall
- No notebooks
- No comandos del repo del cliente
