# Canary Public Report

API_KEY=<redacted>
TOKEN=<redacted>
AWS_SECRET=<redacted>
SECRET_KEY=<redacted>
PRIVATE_KEY=<redacted>
API_KEY=<redacted>
TOKEN=<redacted>
AWS_SECRET=<redacted>
SECRET_KEY=<redacted>
PRIVATE_KEY=<redacted>
{
  "run_id": "20260125_173325_d4ad4f",
  "dir": "/tmp/aquiles_canary/20260125_173325_d4ad4f",
  "canaries": [
    "API_KEY=<redacted>
    "TOKEN=<redacted>
    "AWS_SECRET=<redacted>
    "SECRET_KEY=<redacted>
    "PRIVATE_KEY=<redacted>
  ],
  "timestamp": "2026-01-25T17:33:25"
}
# Canary
API_KEY=<redacted>
TOKEN=<redacted>
AWS_SECRET=<redacted>
SECRET_KEY=<redacted>
PRIVATE_KEY=<redacted>
