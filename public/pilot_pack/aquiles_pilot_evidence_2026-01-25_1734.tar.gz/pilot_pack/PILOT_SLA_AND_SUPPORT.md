# Pilot SLA & Support

## Canales
- Email: support@example.com
- WhatsApp/Telegram (si aplica)

## Horario
- Lunes–Viernes 09:00–18:00 CLT

## Tiempos de respuesta
- Incidente crítico: 4h
- Incidente medio: 24h
- Solicitud normal: 48h

## Definición de incidente
- Leak en artefacto público
- Falla de pipeline repetida
- Publicación accidental
