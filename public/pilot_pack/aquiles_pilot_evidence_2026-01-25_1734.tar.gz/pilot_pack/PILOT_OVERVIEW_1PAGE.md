# Pilot Overview — Aquiles (1 page)

## Alcance del piloto
- Servicio: “Repo Health Report público + sanitizado”.
- Método: análisis estático (no ejecución de código del cliente).
- Duración sugerida: 2–4 semanas.
- Entrega: reportes en runtime + publicación en Faro.

## Responsabilidades
**Equipo Aquiles**
- Generar reportes sanitizados y reproducibles.
- Proveer scripts de verificación (leak scan, canary, reproducibilidad).
- Operación y soporte durante el piloto.

**Cliente**
- Proveer repos públicos o ZIP seguro.
- Validar que la información publicada es aceptable.
- Dar feedback técnico y de negocio.

## Criterios de éxito (cuantificables)
- 100% reportes públicos pasan leak scan.
- 0 incidentes por exposición accidental.
- Tiempo de entrega < 24h desde pago.
- Al menos 2 decisiones/acciones derivadas del reporte.

## Entregables
- Reporte público sanitizado (Markdown).
- Evidencias de sanitización (leak scan report).
- Repro bundle (manifest + hashes).
- Índice público (Faro).

## Riesgos / limitaciones
- No analiza código ejecutado (solo estático).
- No cubre secretos en binarios/PDFs/base64 sin decodificar.
- Depende de configuración correcta de sanitización.
- No reemplaza auditorías de seguridad profundas.
