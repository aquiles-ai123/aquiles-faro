# License & Commercial Terms (Simple)

## Uso comercial
- El reporte generado puede ser usado por el cliente para fines internos y externos.

## Propiedad de datos
- El cliente mantiene propiedad de su repositorio y datos.
- Aquiles sólo procesa inputs para generar el reporte.

## Confidencialidad
- No se publica PII ni secretos.
- Artefactos públicos son sanitizados.

## Limitaciones
- No se garantiza detección total de vulnerabilidades.
- Servicio basado en análisis estático.
- Responsabilidad limitada al valor del servicio contratado.
